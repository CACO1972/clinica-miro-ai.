import React, { useState, useEffect } from 'react';
import { Heart, Brain, Calculator, MapPin, Download, Share2, ChevronRight, AlertCircle, CheckCircle, TrendingUp, Users, Clock, DollarSign, Shield, Star, Phone, Mail, Calendar } from 'lucide-react';

// ============================================================================
// UTILITY FUNCTIONS & DATA
// ============================================================================

const QUESTIONS = [
  {
    id: 'smoking',
    title: 'Hábitos de Tabaquismo',
    question: '¿Fumas actualmente?',
    info: 'El tabaco es el factor de riesgo más importante. Reduce el flujo sanguíneo al hueso en un 30%, dificultando la cicatrización.',
    options: [
      { value: 0, label: 'No fumo', emoji: '✅', risk: 1.0 },
      { value: 1, label: 'Ex-fumador (+1 año)', emoji: '💪', risk: 0.97 },
      { value: 2, label: 'Menos de 10 cigarrillos/día', emoji: '⚠️', risk: 0.94 },
      { value: 3, label: '10-20 cigarrillos/día', emoji: '🔶', risk: 0.87 },
      { value: 4, label: 'Más de 20 cigarrillos/día', emoji: '🔴', risk: 0.78 }
    ]
  },
  {
    id: 'diabetes',
    title: 'Control Metabólico',
    question: '¿Tienes diabetes?',
    info: 'La diabetes mal controlada afecta la capacidad de tu cuerpo para sanar. Con buen control (HbA1c <7%), las tasas de éxito son excelentes.',
    options: [
      { value: 0, label: 'No tengo diabetes', emoji: '✅', risk: 1.0 },
      { value: 1, label: 'Pre-diabetes', emoji: '⚠️', risk: 0.96 },
      { value: 2, label: 'Tipo 2 controlada (HbA1c <7%)', emoji: '💊', risk: 0.93 },
      { value: 3, label: 'Tipo 1 controlada', emoji: '💉', risk: 0.88 },
      { value: 4, label: 'Diabetes no controlada', emoji: '🔴', risk: 0.75 }
    ]
  },
  {
    id: 'bruxism',
    title: 'Parafunciones',
    question: '¿Aprietas o rechinas los dientes?',
    info: 'El bruxismo genera fuerzas excesivas sobre el implante. Con una placa oclusal nocturna, podemos proteger tu inversión.',
    options: [
      { value: 0, label: 'No tengo bruxismo', emoji: '😊', risk: 1.0 },
      { value: 1, label: 'Leve, uso placa nocturna', emoji: '🦷', risk: 0.96 },
      { value: 2, label: 'Moderado, con tratamiento', emoji: '⚠️', risk: 0.92 },
      { value: 3, label: 'Severo, sin control', emoji: '🔴', risk: 0.86 }
    ]
  },
  {
    id: 'periodontal',
    title: 'Salud de las Encías',
    question: '¿Cuál es el estado actual de tus encías?',
    info: 'Las bacterias que causan enfermedad periodontal también pueden afectar los implantes. La buena noticia: es 100% prevenible con higiene.',
    options: [
      { value: 0, label: 'Encías sanas', emoji: '💪', risk: 1.0 },
      { value: 1, label: 'Gingivitis ocasional', emoji: '⚠️', risk: 0.95 },
      { value: 2, label: 'Periodontitis tratada', emoji: '💊', risk: 0.88 },
      { value: 3, label: 'Periodontitis activa', emoji: '🔴', risk: 0.76 }
    ]
  },
  {
    id: 'hygiene',
    title: 'Higiene Oral',
    question: '¿Cómo describirías tu rutina de higiene oral?',
    info: 'Los implantes requieren MÁS cuidado que los dientes naturales. Una buena higiene es la clave del éxito a largo plazo.',
    options: [
      { value: 0, label: '2-3 veces/día + hilo + enjuague', emoji: '⭐', risk: 1.0 },
      { value: 1, label: '2 veces/día + hilo dental', emoji: '✅', risk: 0.98 },
      { value: 2, label: '2 veces/día básico', emoji: '💪', risk: 0.95 },
      { value: 3, label: '1 vez/día', emoji: '⚠️', risk: 0.89 },
      { value: 4, label: 'Irregular', emoji: '🔴', risk: 0.79 }
    ]
  },
  {
    id: 'bone_loss',
    title: 'Tiempo sin Diente',
    question: '¿Cuánto tiempo llevas sin el/los diente(s)?',
    info: 'El hueso se reabsorbe progresivamente sin el diente. Cuanto antes actuemos, mejor será el hueso disponible.',
    options: [
      { value: 0, label: 'Aún tengo el diente', emoji: '🦷', risk: 1.0 },
      { value: 1, label: 'Menos de 3 meses', emoji: '🆕', risk: 0.98 },
      { value: 2, label: '3-12 meses', emoji: '⏱️', risk: 0.96 },
      { value: 3, label: '1-3 años', emoji: '⚠️', risk: 0.92 },
      { value: 4, label: 'Más de 3 años', emoji: '🔴', risk: 0.87 }
    ]
  },
  {
    id: 'previous_implants',
    title: 'Experiencia Previa',
    question: '¿Has tenido implantes dentales anteriormente?',
    info: 'Tu historial nos ayuda a personalizar el tratamiento. Si tuviste complicaciones, identificaremos la causa.',
    options: [
      { value: 0, label: 'Primera vez', emoji: '🆕', risk: 1.0 },
      { value: 1, label: 'Sí, exitosos', emoji: '✅', risk: 1.03 },
      { value: 2, label: 'Sí, con complicaciones menores', emoji: '⚠️', risk: 0.88 },
      { value: 3, label: 'Sí, fracasaron', emoji: '🔴', risk: 0.71 }
    ]
  },
  {
    id: 'tooth_loss_cause',
    title: 'Causa de Pérdida Dental',
    question: '¿Por qué perdiste el/los diente(s)?',
    info: 'La causa nos indica el estado del hueso y tejidos. Cada situación requiere un enfoque específico.',
    options: [
      { value: 0, label: 'Caries', emoji: '🦷', risk: 1.0 },
      { value: 1, label: 'Golpe o accidente', emoji: '💥', risk: 0.98 },
      { value: 2, label: 'Enfermedad de las encías', emoji: '⚠️', risk: 0.88 },
      { value: 3, label: 'Otra razón', emoji: '❓', risk: 0.95 }
    ]
  },
  {
    id: 'location',
    title: 'Ubicación del Implante',
    question: '¿Dónde necesitas el implante?',
    info: 'La ubicación afecta la complejidad. El maxilar posterior tiene menos densidad ósea, requiriendo más cuidado.',
    options: [
      { value: 0, label: 'Anterior superior (dientes de adelante arriba)', emoji: '😁', risk: 0.98 },
      { value: 1, label: 'Posterior superior (muelas arriba)', emoji: '🦷', risk: 0.91 },
      { value: 2, label: 'Anterior inferior (dientes de adelante abajo)', emoji: '💪', risk: 1.0 },
      { value: 3, label: 'Posterior inferior (muelas abajo)', emoji: '🦴', risk: 0.95 }
    ]
  }
];

const DENSITY_QUESTIONS = [
  {
    id: 'fractures',
    question: '¿Has tenido fracturas de hueso después de una caída leve?',
    info: 'Las fracturas por trauma mínimo son la señal más clara de huesos débiles.',
    options: [
      { value: 0, label: 'No, nunca', emoji: '✅' },
      { value: 1, label: 'Sí, una vez', emoji: '⚠️' },
      { value: 2, label: 'Sí, múltiples veces', emoji: '🔴' }
    ]
  },
  {
    id: 'height_loss',
    question: '¿Has notado pérdida de estatura en los últimos años?',
    info: 'Perder más de 3cm puede indicar fracturas vertebrales por osteoporosis.',
    options: [
      { value: 0, label: 'No', emoji: '✅' },
      { value: 1, label: 'Sí, notablemente', emoji: '⚠️' },
      { value: 2, label: 'No estoy segura', emoji: '❓' }
    ]
  },
  {
    id: 'family_history',
    question: '¿Alguno de tus padres tuvo osteoporosis o fractura de cadera?',
    info: 'Los antecedentes familiares aumentan tu riesgo 2-3 veces.',
    options: [
      { value: 0, label: 'No', emoji: '✅' },
      { value: 1, label: 'Sí', emoji: '⚠️' },
      { value: 2, label: 'Desconozco', emoji: '❓' }
    ]
  },
  {
    id: 'corticoids',
    question: '¿Has tomado corticoides (prednisona) por más de 3 meses?',
    info: 'Los corticoides pueden debilitar los huesos significativamente.',
    options: [
      { value: 0, label: 'Nunca', emoji: '✅' },
      { value: 1, label: 'Sí, en el pasado', emoji: '⚠️' },
      { value: 2, label: 'Actualmente', emoji: '🔴' }
    ]
  },
  {
    id: 'menopause',
    question: '¿Hace cuánto tiempo pasaste por la menopausia?',
    info: 'Los primeros 5 años post-menopausia son críticos para la salud ósea.',
    options: [
      { value: 0, label: 'Pre-menopausia', emoji: '✅' },
      { value: 1, label: 'Menos de 5 años', emoji: '⚠️' },
      { value: 2, label: 'Más de 5 años', emoji: '🔴' }
    ]
  }
];

// ============================================================================
// COMPONENT: WelcomeScreen
// ============================================================================

function WelcomeScreen({ onStart }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-4xl w-full animate-fadeIn">
        <div className="bg-white/5 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/10 overflow-hidden">
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-8 text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-3">ImplantX™</h1>
            <p className="text-xl opacity-90">Tu Evaluación Inteligente de Implantes Dentales</p>
          </div>
          
          <div className="p-8">
            <div className="text-center mb-8">
              <div className="w-24 h-24 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full mx-auto mb-4 flex items-center justify-center text-5xl">
                🦷
              </div>
              <h2 className="text-3xl font-bold mb-4">¡Hola! Soy Río, tu asistente dental con IA</h2>
              <p className="text-xl text-gray-300 mb-6">
                En solo 3 minutos, te daré una evaluación personalizada con:
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-4 mb-8">
              <div className="bg-white/5 rounded-xl p-6 text-center hover:bg-white/10 transition-all">
                <div className="text-4xl mb-3">📊</div>
                <div className="font-bold mb-2">Tu Probabilidad de Éxito</div>
                <div className="text-sm text-gray-400">Basada en 17,025 casos reales</div>
              </div>
              <div className="bg-white/5 rounded-xl p-6 text-center hover:bg-white/10 transition-all">
                <div className="text-4xl mb-3">💰</div>
                <div className="font-bold mb-2">Costo Estimado</div>
                <div className="text-sm text-gray-400">Personalizado para tu caso</div>
              </div>
              <div className="bg-white/5 rounded-xl p-6 text-center hover:bg-white/10 transition-all">
                <div className="text-4xl mb-3">👨‍⚕️</div>
                <div className="font-bold mb-2">Especialistas Ideales</div>
                <div className="text-sm text-gray-400">Cerca de ti, según tu caso</div>
              </div>
            </div>

            <button
              onClick={onStart}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold py-5 rounded-xl transition-all transform hover:scale-105 shadow-lg flex items-center justify-center gap-2 text-lg"
            >
              Comenzar Evaluación <ChevronRight className="w-6 h-6" />
            </button>

            <p className="text-center text-sm text-gray-400 mt-4">
              🔒 Tus datos están seguros y son confidenciales
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// COMPONENT: UserDataForm
// ============================================================================

function UserDataForm({ userData, onUpdate, onContinue }) {
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    
    if (!userData.name || userData.name.trim().length < 2) {
      newErrors.name = 'Por favor ingresa tu nombre completo';
    }
    
    if (!userData.age || parseInt(userData.age) < 18 || parseInt(userData.age) > 100) {
      newErrors.age = 'Edad debe estar entre 18 y 100 años';
    }
    
    if (!userData.gender) {
      newErrors.gender = 'Por favor selecciona tu género';
    }
    
    if (userData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userData.email)) {
      newErrors.email = 'Email inválido';
    }
    
    if (userData.phone && !/^\+?[\d\s-]{8,}$/.test(userData.phone)) {
      newErrors.phone = 'Teléfono inválido';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      onContinue();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="bg-white/5 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/10 p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full mx-auto mb-4 flex items-center justify-center text-3xl">
              👤
            </div>
            <h2 className="text-3xl font-bold mb-2">Cuéntame sobre ti</h2>
            <p className="text-gray-300">Esto me ayudará a personalizar tu evaluación</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">Nombre Completo *</label>
              <input
                type="text"
                value={userData.name}
                onChange={(e) => onUpdate({ ...userData, name: e.target.value })}
                className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="Ej: María González"
              />
              {errors.name && <p className="text-red-400 text-sm mt-1">{errors.name}</p>}
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Edad *</label>
                <input
                  type="number"
                  value={userData.age}
                  onChange={(e) => onUpdate({ ...userData, age: e.target.value })}
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="Ej: 45"
                  min="18"
                  max="100"
                />
                {errors.age && <p className="text-red-400 text-sm mt-1">{errors.age}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Género *</label>
                <select
                  value={userData.gender}
                  onChange={(e) => onUpdate({ ...userData, gender: e.target.value })}
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  <option value="">Seleccionar</option>
                  <option value="male">Masculino</option>
                  <option value="female">Femenino</option>
                  <option value="other">Otro</option>
                </select>
                {errors.gender && <p className="text-red-400 text-sm mt-1">{errors.gender}</p>}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Email (Opcional)</label>
              <input
                type="email"
                value={userData.email}
                onChange={(e) => onUpdate({ ...userData, email: e.target.value })}
                className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="tu@email.com"
              />
              {errors.email && <p className="text-red-400 text-sm mt-1">{errors.email}</p>}
              <p className="text-xs text-gray-400 mt-1">Para enviarte los resultados</p>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Teléfono (Opcional)</label>
              <input
                type="tel"
                value={userData.phone}
                onChange={(e) => onUpdate({ ...userData, phone: e.target.value })}
                className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="+56 9 1234 5678"
              />
              {errors.phone && <p className="text-red-400 text-sm mt-1">{errors.phone}</p>}
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold py-4 rounded-xl transition-all transform hover:scale-105 shadow-lg flex items-center justify-center gap-2"
            >
              Continuar <ChevronRight className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// COMPONENT: QuestionScreen
// ============================================================================

function QuestionScreen({ question, currentIndex, total, onAnswer, onBack }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-3xl w-full">
        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-300">Pregunta {currentIndex + 1} de {total}</span>
            <span className="text-sm text-gray-300">{Math.round(((currentIndex + 1) / total) * 100)}%</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full transition-all duration-500"
              style={{ width: `${((currentIndex + 1) / total) * 100}%` }}
            />
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/10 p-8">
          {/* Question Header */}
          <div className="text-center mb-8">
            <div className="inline-block bg-purple-600/20 px-4 py-2 rounded-full mb-4">
              <span className="text-sm font-medium text-purple-300">{question.title}</span>
            </div>
            <h2 className="text-3xl font-bold mb-4">{question.question}</h2>
          </div>

          {/* Info Box */}
          <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4 mb-6 flex gap-3">
            <Brain className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-blue-200">{question.info}</p>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {question.options.map((option) => (
              <button
                key={option.value}
                onClick={() => onAnswer(option.value)}
                className="w-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-purple-500/50 rounded-xl p-4 transition-all text-left flex items-center gap-4 group"
              >
                <div className="text-3xl">{option.emoji}</div>
                <div className="flex-1">
                  <div className="font-medium group-hover:text-purple-300 transition-colors">
                    {option.label}
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-purple-400 transition-colors" />
              </button>
            ))}
          </div>

          {/* Back Button */}
          {currentIndex > 0 && (
            <button
              onClick={onBack}
              className="mt-6 text-gray-400 hover:text-white transition-colors flex items-center gap-2"
            >
              ← Volver
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// COMPONENT: DensityIntro
// ============================================================================

function DensityIntro({ onContinue, onSkip }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="bg-white/5 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/10 p-8">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full mx-auto mb-4 flex items-center justify-center text-4xl">
              🦴
            </div>
            <h2 className="text-3xl font-bold mb-4">DensityPro™ para Mujeres</h2>
            <p className="text-xl text-gray-300 mb-4">
              Detecté que eres mujer mayor de 45 años
            </p>
            <p className="text-gray-400">
              La densidad ósea es crucial para el éxito de los implantes. Te haré 5 preguntas
              adicionales para evaluar tu salud ósea con mayor precisión.
            </p>
          </div>

          <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-6 mb-6">
            <h3 className="font-bold mb-3 flex items-center gap-2">
              <Shield className="w-5 h-5 text-purple-400" />
              ¿Por qué es importante?
            </h3>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>• La osteoporosis afecta al 30% de las mujeres post-menopáusicas</li>
              <li>• Puede reducir la tasa de éxito del implante en un 15-20%</li>
              <li>• Con detección temprana, podemos optimizar tu tratamiento</li>
            </ul>
          </div>

          <div className="space-y-3">
            <button
              onClick={onContinue}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-4 rounded-xl transition-all transform hover:scale-105 shadow-lg flex items-center justify-center gap-2"
            >
              Continuar con DensityPro <ChevronRight className="w-5 h-5" />
            </button>
            <button
              onClick={onSkip}
              className="w-full bg-white/5 hover:bg-white/10 border border-white/20 text-white font-medium py-4 rounded-xl transition-all"
            >
              Saltar (menos preciso)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// COMPONENT: CalculatingScreen
// ============================================================================

function CalculatingScreen() {
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    { icon: '🧮', text: 'Analizando tus respuestas...' },
    { icon: '📊', text: 'Comparando con 17,025 casos clínicos...' },
    { icon: '🤖', text: 'Aplicando algoritmos de IA...' },
    { icon: '🎯', text: 'Calculando tu probabilidad personalizada...' },
    { icon: '✨', text: 'Preparando recomendaciones...' }
  ];

  useEffect(() => {
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 2;
      });
    }, 50);

    const stepInterval = setInterval(() => {
      setCurrentStep(prev => (prev < steps.length - 1 ? prev + 1 : prev));
    }, 600);

    return () => {
      clearInterval(progressInterval);
      clearInterval(stepInterval);
    };
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-lg w-full">
        <div className="bg-white/5 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/10 p-8">
          <div className="text-center mb-8">
            <div className="w-24 h-24 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full mx-auto mb-6 flex items-center justify-center animate-pulse">
              <Brain className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Procesando tu Evaluación</h2>
            <p className="text-gray-400">Esto tomará solo unos segundos...</p>
          </div>

          <div className="mb-8">
            <div className="w-full bg-white/10 rounded-full h-3 mb-2">
              <div 
                className="bg-gradient-to-r from-purple-600 to-blue-600 h-3 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="text-center text-sm text-gray-400">{progress}%</div>
          </div>

          <div className="space-y-3">
            {steps.map((step, index) => (
              <div
                key={index}
                className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-300 ${
                  index <= currentStep 
                    ? 'bg-purple-500/20 border border-purple-500/30' 
                    : 'bg-white/5 border border-white/10 opacity-40'
                }`}
              >
                <div className="text-2xl">{step.icon}</div>
                <div className="text-sm">{step.text}</div>
                {index === currentStep && (
                  <div className="ml-auto">
                    <div className="w-5 h-5 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
                  </div>
                )}
                {index < currentStep && (
                  <div className="ml-auto">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// COMPONENT: ResultsScreen
// ============================================================================

function ResultsScreen({ results, userData, onBookAppointment }) {
  const riskLevel = results.riskLevel;

  return (
    <div className="min-h-screen p-4 py-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-2">
            ¡Tu Evaluación está Lista, {userData.name.split(' ')[0]}!
          </h1>
          <p className="text-gray-300">Estos son tus resultados personalizados</p>
        </div>

        {/* Main Result Card */}
        <div className="bg-white/5 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/10 p-8 mb-6">
          <div className="text-center mb-6">
            <div className={`inline-block bg-gradient-to-r ${riskLevel.color} rounded-full p-6 mb-4`}>
              <div className="text-6xl">{riskLevel.emoji}</div>
            </div>
            <h2 className="text-3xl font-bold mb-2">{riskLevel.level}</h2>
            <p className="text-xl text-gray-300 mb-4">{riskLevel.message}</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-6">
            <div className="bg-white/5 rounded-xl p-6 text-center">
              <div className="text-5xl font-bold mb-2 bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
                {results.probabilityPercent}%
              </div>
              <div className="text-sm text-gray-400">Probabilidad de Éxito</div>
              <div className="text-xs text-gray-500 mt-1">
                Rango: {(results.ciLower * 100).toFixed(1)}% - {(results.ciUpper * 100).toFixed(1)}%
              </div>
            </div>

            <div className="bg-white/5 rounded-xl p-6 text-center">
              <div className="text-3xl font-bold mb-2">
                ${results.estimatedCost.average.toLocaleString()}
              </div>
              <div className="text-sm text-gray-400">Costo Estimado (CLP)</div>
              <div className="text-xs text-gray-500 mt-1">
                ${results.estimatedCost.min.toLocaleString()} - ${results.estimatedCost.max.toLocaleString()}
              </div>
            </div>

            <div className="bg-white/5 rounded-xl p-6 text-center">
              <div className="text-3xl font-bold mb-2">{results.timeline}</div>
              <div className="text-sm text-gray-400">Tiempo Estimado</div>
              <div className="text-xs text-gray-500 mt-1">Desde consulta hasta corona</div>
            </div>
          </div>

          <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
            <p className="text-sm text-center text-blue-200">{riskLevel.description}</p>
          </div>
        </div>

        {/* Recommendations */}
        <div className="bg-white/5 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/10 p-8 mb-6">
          <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <AlertCircle className="w-6 h-6 text-purple-400" />
            Recomendaciones Personalizadas
          </h3>
          <div className="space-y-4">
            {results.recommendations.map((rec, index) => (
              <div 
                key={index}
                className={`border-l-4 ${
                  rec.color === 'red' ? 'border-red-500 bg-red-500/10' :
                  rec.color === 'orange' ? 'border-orange-500 bg-orange-500/10' :
                  'border-green-500 bg-green-500/10'
                } rounded-r-xl p-4`}
              >
                <div className="flex items-start gap-4">
                  <div className="text-3xl">{rec.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`text-xs font-bold px-2 py-1 rounded ${
                        rec.color === 'red' ? 'bg-red-500' :
                        rec.color === 'orange' ? 'bg-orange-500' :
                        'bg-green-500'
                      }`}>
                        {rec.priority}
                      </span>
                      <h4 className="font-bold">{rec.title}</h4>
                    </div>
                    <p className="text-sm text-gray-300 mb-2">{rec.description}</p>
                    <div className="flex flex-wrap gap-4 text-xs">
                      <span className="text-green-400">💪 {rec.impact}</span>
                      <span className="text-blue-400">⏱️ {rec.timeline}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cost Breakdown */}
        <div className="bg-white/5 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/10 p-8 mb-6">
          <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <DollarSign className="w-6 h-6 text-green-400" />
            Desglose de Costos
          </h3>
          <div className="space-y-3">
            {results.estimatedCost.breakdown.map((item, index) => (
              <div key={index} className="flex justify-between items-center p-3 bg-white/5 rounded-lg">
                <span className="text-gray-300">{item.item}</span>
                <span className="font-bold">${item.cost.toLocaleString()} CLP</span>
              </div>
            ))}
            <div className="border-t border-white/20 pt-3 mt-3">
              <div className="flex justify-between items-center text-xl font-bold">
                <span>Total Estimado</span>
                <span className="text-green-400">${results.estimatedCost.average.toLocaleString()} CLP</span>
              </div>
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-4 text-center">
            * Precios orientativos. Consulta con el especialista para cotización final.
          </p>
        </div>

        {/* Specialists */}
        <div className="bg-white/5 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/10 p-8 mb-6">
          <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Users className="w-6 h-6 text-purple-400" />
            Especialistas Recomendados para Tu Caso
          </h3>
          <div className="grid md:grid-cols-3 gap-4">
            {results.specialists.map((specialist, index) => (
              <div key={index} className="bg-white/5 rounded-xl p-6 hover:bg-white/10 transition-all border border-white/10">
                <div className="flex items-start justify-between mb-4">
                  <div className="text-5xl">{specialist.photo}</div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-yellow-400 mb-1">
                      <Star className="w-4 h-4 fill-current" />
                      <span className="font-bold">{specialist.rating}</span>
                    </div>
                    <div className={`text-xs px-2 py-1 rounded ${
                      specialist.matchScore >= 90 ? 'bg-green-500' : 
                      specialist.matchScore >= 80 ? 'bg-blue-500' : 'bg-gray-500'
                    }`}>
                      {specialist.matchScore}% Match
                    </div>
                  </div>
                </div>
                <h4 className="font-bold mb-1">{specialist.name}</h4>
                <p className="text-sm text-gray-400 mb-3">{specialist.clinic}</p>
                <div className="space-y-2 text-xs text-gray-300">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    {specialist.experience} - {specialist.specialty}
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    {specialist.distance}
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {specialist.availability}
                  </div>
                </div>
                <button
                  onClick={() => onBookAppointment(specialist)}
                  className="w-full mt-4 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold py-2 rounded-lg transition-all text-sm"
                >
                  Agendar Consulta
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid md:grid-cols-2 gap-4">
          <button className="bg-white/5 hover:bg-white/10 border border-white/20 rounded-xl p-4 flex items-center justify-center gap-2 transition-all">
            <Download className="w-5 h-5" />
            Descargar Reporte PDF
          </button>
          <button className="bg-white/5 hover:bg-white/10 border border-white/20 rounded-xl p-4 flex items-center justify-center gap-2 transition-all">
            <Share2 className="w-5 h-5" />
            Compartir Resultados
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// MAIN APP COMPONENT
// ============================================================================

export default function ImplantXApp() {
  const [stage, setStage] = useState('welcome');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [densityAnswers, setDensityAnswers] = useState({});
  const [densityQuestion, setDensityQuestion] = useState(0);
  const [showDensityPro, setShowDensityPro] = useState(false);
  const [userData, setUserData] = useState({ 
    name: '', 
    age: '', 
    gender: '', 
    email: '', 
    phone: '' 
  });
  const [results, setResults] = useState(null);

  // Calculation Logic (Improved)
  const calculateResults = () => {
    setStage('calculating');
    
    setTimeout(() => {
      let successProb = 0.964; // Baseline científico actualizado
      
      // Aplicar coeficientes de cada respuesta
      Object.entries(answers).forEach(([key, value]) => {
        const question = QUESTIONS.find(q => q.id === key);
        if (question && question.options[value]) {
          successProb *= question.options[value].risk;
        }
      });

      // Factor de densidad ósea (DensityPro) - mejorado
      if (showDensityPro && Object.keys(densityAnswers).length > 0) {
        const densityScore = Object.values(densityAnswers).reduce((a, b) => a + b, 0);
        // Escala logarítmica más realista
        const densityFactor = Math.max(0.75, 1.0 - (densityScore * 0.04));
        successProb *= densityFactor;
      }

      // Interacciones sinérgicas mejoradas
      if (answers.smoking >= 2 && answers.diabetes >= 2) {
        successProb *= 0.91; // Interacción tabaco-diabetes
      }
      if (answers.smoking >= 3 && answers.hygiene >= 3) {
        successProb *= 0.90; // Interacción tabaco-higiene
      }
      if (answers.periodontal >= 2 && answers.hygiene >= 3) {
        successProb *= 0.93; // Higiene pobre con enfermedad periodontal
      }

      // Límites realistas basados en literatura
      successProb = Math.max(0.50, Math.min(0.985, successProb));

      const result = {
        probability: successProb,
        probabilityPercent: (successProb * 100).toFixed(1),
        ciLower: Math.max(0.50, successProb - 0.03),
        ciUpper: Math.min(0.985, successProb + 0.03),
        riskLevel: getRiskLevel(successProb),
        recommendations: generateRecommendations(),
        estimatedCost: calculateCost(),
        timeline: calculateTimeline(successProb),
        specialists: findSpecialists(successProb)
      };

      setTimeout(() => {
        setResults(result);
        setStage('results');
      }, 1500);
    }, 500);
  };

  const getRiskLevel = (prob) => {
    if (prob >= 0.92) return {
      level: 'EXCELENTE',
      color: 'from-emerald-500 to-green-600',
      emoji: '🌟',
      message: '¡Eres un candidato ideal para implantes!',
      description: 'Tu perfil es excelente. Tienes muy alta probabilidad de éxito a largo plazo.'
    };
    if (prob >= 0.85) return {
      level: 'BUENO',
      color: 'from-blue-500 to-cyan-600',
      emoji: '✅',
      message: 'Muy buen candidato con preparación mínima',
      description: 'Tu perfil es favorable. Con algunos ajustes simples, tendrás resultados excelentes.'
    };
    if (prob >= 0.75) return {
      level: 'MODERADO',
      color: 'from-yellow-500 to-orange-500',
      emoji: '⚠️',
      message: 'Buen candidato con optimización necesaria',
      description: 'Tu caso requiere preparación específica, pero definitivamente es viable.'
    };
    if (prob >= 0.65) return {
      level: 'ALTO',
      color: 'from-orange-500 to-red-500',
      emoji: '🔶',
      message: 'Necesitas protocolo especializado',
      description: 'Tu caso es complejo pero tratable con el especialista adecuado y preparación.'
    };
    return {
      level: 'MUY ALTO',
      color: 'from-red-500 to-red-700',
      emoji: '🔴',
      message: 'Requiere evaluación multidisciplinaria',
      description: 'Tu caso necesita preparación extensa, pero no imposible. Trabajaremos en equipo.'
    };
  };

  const generateRecommendations = () => {
    const recs = [];
    
    if (answers.smoking >= 2) {
      recs.push({
        priority: 'CRÍTICA',
        icon: '🚭',
        title: 'Dejar de Fumar',
        description: 'Suspender tabaco mínimo 2 semanas antes y 8 semanas después de la cirugía',
        impact: '+12% probabilidad de éxito',
        timeline: '2 semanas antes',
        color: 'red'
      });
    }

    if (answers.diabetes >= 3) {
      recs.push({
        priority: 'CRÍTICA',
        icon: '🩸',
        title: 'Control de Diabetes',
        description: 'HbA1c debe estar <7% antes de la cirugía. Trabajo conjunto con endocrinólogo.',
        impact: '+10% probabilidad de éxito',
        timeline: '4-8 semanas antes',
        color: 'red'
      });
    }

    if (answers.bruxism >= 2) {
      recs.push({
        priority: 'IMPORTANTE',
        icon: '🦷',
        title: 'Placa Oclusal',
        description: 'Uso obligatorio de placa de descarga nocturna para proteger el implante',
        impact: 'Protege inversión a largo plazo',
        timeline: 'Desde ahora y de por vida',
        color: 'orange'
      });
    }

    if (answers.periodontal >= 2) {
      recs.push({
        priority: 'CRÍTICA',
        icon: '🦠',
        title: 'Tratamiento Periodontal',
        description: 'Controlar completamente la enfermedad antes del implante',
        impact: '+15% probabilidad de éxito',
        timeline: '6-12 semanas antes',
        color: 'red'
      });
    }

    if (answers.hygiene >= 3) {
      recs.push({
        priority: 'IMPORTANTE',
        icon: '🪥',
        title: 'Mejorar Higiene Oral',
        description: 'Cepillado 3x/día, hilo dental diario, e irrigador bucal',
        impact: '+8% probabilidad de éxito',
        timeline: 'Desde ahora',
        color: 'orange'
      });
    }

    if (answers.bone_loss >= 3) {
      recs.push({
        priority: 'IMPORTANTE',
        icon: '🦴',
        title: 'Evaluación de Injerto Óseo',
        description: 'Probablemente necesites regeneración ósea guiada (GBR)',
        impact: 'Permite colocación de implante',
        timeline: '3-6 meses antes del implante',
        color: 'orange'
      });
    }

    if (showDensityPro) {
      const densityScore = Object.values(densityAnswers).reduce((a, b) => a + b, 0);
      if (densityScore >= 4) {
        recs.push({
          priority: 'CRÍTICA',
          icon: '🦴',
          title: 'Densitometría Ósea (DEXA)',
          description: 'Evaluación médica de densidad ósea. Posible tratamiento con bifosfonatos.',
          impact: 'Protocolo personalizado según resultado',
          timeline: '2-4 semanas antes',
          color: 'red'
        });
      }
    }

    return recs.length > 0 ? recs : [{
      priority: 'MANTENIMIENTO',
      icon: '✨',
      title: 'Mantén tu Salud Actual',
      description: 'Continúa con tus excelentes hábitos de salud oral y general',
      impact: 'Mantiene alta probabilidad de éxito',
      timeline: 'Siempre',
      color: 'green'
    }];
  };

  const calculateCost = () => {
    let baseCost = 950000; // CLP - costo base implante
    
    if (answers.bone_loss >= 3) baseCost += 400000; // Injerto óseo
    if (answers.periodontal >= 2) baseCost += 200000; // Tratamiento periodontal
    if (answers.bruxism >= 2) baseCost += 150000; // Placa oclusal
    if (answers.location === 1) baseCost += 250000; // Zona estética compleja
    if (answers.diabetes >= 3) baseCost += 100000; // Protocolo especial
    
    const variability = 0.12;
    
    return {
      min: Math.round(baseCost * (1 - variability)),
      max: Math.round(baseCost * (1 + variability)),
      average: baseCost,
      breakdown: [
        { item: 'Implante + Cirugía', cost: 680000 },
        { item: 'Pilar protésico', cost: 150000 },
        { item: 'Corona cerámica premium', cost: 420000 },
        ...(answers.bone_loss >= 3 ? [{ item: 'Injerto óseo + membrana', cost: 400000 }] : []),
        ...(answers.bruxism >= 2 ? [{ item: 'Placa oclusal', cost: 150000 }] : []),
        ...(answers.periodontal >= 2 ? [{ item: 'Tratamiento periodontal', cost: 200000 }] : []),
        ...(answers.diabetes >= 3 ? [{ item: 'Protocolo diabetes', cost: 100000 }] : [])
      ]
    };
  };

  const calculateTimeline = (prob) => {
    let months = 3;
    
    if (answers.bone_loss >= 3) months += 4; // Injerto necesita tiempo
    if (answers.periodontal >= 2) months += 2; // Tratamiento periodontal
    if (prob < 0.75) months += 1; // Casos complejos necesitan más tiempo
    
    return `${months}-${months + 2} meses`;
  };

  const findSpecialists = (prob) => {
    const specialists = [
      {
        name: 'Dra. María González Rojas',
        clinic: 'Centro Dental Providencia',
        experience: '15 años',
        specialty: 'Casos complejos y regeneración',
        distance: '2.3 km',
        rating: 4.9,
        availability: 'Esta semana',
        matchScore: prob < 0.75 ? 96 : 85,
        photo: '👩‍⚕️'
      },
      {
        name: 'Dr. Carlos Pérez Silva',
        clinic: 'Clínica ImplantX Las Condes',
        experience: '12 años',
        specialty: 'Implantología general',
        distance: '4.1 km',
        rating: 4.8,
        availability: 'Próxima semana',
        matchScore: prob >= 0.85 ? 94 : 78,
        photo: '👨‍⚕️'
      },
      {
        name: 'Dra. Patricia Silva Mora',
        clinic: 'Dental Pro Ñuñoa',
        experience: '18 años',
        specialty: 'Regeneración ósea avanzada',
        distance: '3.5 km',
        rating: 4.9,
        availability: 'En 2 semanas',
        matchScore: answers.bone_loss >= 3 ? 97 : 72,
        photo: '👩‍⚕️'
      }
    ];

    return specialists.sort((a, b) => b.matchScore - a.matchScore);
  };

  // Handlers
  const handleAnswer = (value) => {
    setAnswers({ ...answers, [QUESTIONS[currentQuestion].id]: value });
    
    setTimeout(() => {
      if (currentQuestion < QUESTIONS.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      } else {
        // Check if DensityPro needed
        if (userData.gender === 'female' && parseInt(userData.age) > 45 && !showDensityPro) {
          setShowDensityPro(true);
          setStage('density_intro');
        } else {
          calculateResults();
        }
      }
    }, 300);
  };

  const handleDensityAnswer = (value) => {
    setDensityAnswers({ ...densityAnswers, [DENSITY_QUESTIONS[densityQuestion].id]: value });
    
    setTimeout(() => {
      if (densityQuestion < DENSITY_QUESTIONS.length - 1) {
        setDensityQuestion(densityQuestion + 1);
      } else {
        calculateResults();
      }
    }, 300);
  };

  const handleBack = () => {
    if (stage === 'questions' && currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      const newAnswers = { ...answers };
      delete newAnswers[QUESTIONS[currentQuestion - 1].id];
      setAnswers(newAnswers);
    } else if (stage === 'density' && densityQuestion > 0) {
      setDensityQuestion(densityQuestion - 1);
      const newAnswers = { ...densityAnswers };
      delete newAnswers[DENSITY_QUESTIONS[densityQuestion - 1].id];
      setDensityAnswers(newAnswers);
    }
  };

  const handleBookAppointment = (specialist) => {
    alert(`¡Excelente! Redirigiendo a agendar con ${specialist.name}...`);
    // Aquí integrarías con sistema de agendamiento real
  };

  // Render appropriate screen
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
      {stage === 'welcome' && (
        <WelcomeScreen onStart={() => setStage('user_data')} />
      )}

      {stage === 'user_data' && (
        <UserDataForm 
          userData={userData}
          onUpdate={setUserData}
          onContinue={() => setStage('questions')}
        />
      )}

      {stage === 'questions' && (
        <QuestionScreen
          question={QUESTIONS[currentQuestion]}
          currentIndex={currentQuestion}
          total={QUESTIONS.length}
          onAnswer={handleAnswer}
          onBack={handleBack}
        />
      )}

      {stage === 'density_intro' && (
        <DensityIntro
          onContinue={() => setStage('density')}
          onSkip={calculateResults}
        />
      )}

      {stage === 'density' && (
        <QuestionScreen
          question={DENSITY_QUESTIONS[densityQuestion]}
          currentIndex={densityQuestion}
          total={DENSITY_QUESTIONS.length}
          onAnswer={handleDensityAnswer}
          onBack={handleBack}
        />
      )}

      {stage === 'calculating' && <CalculatingScreen />}

      {stage === 'results' && results && (
        <ResultsScreen 
          results={results}
          userData={userData}
          onBookAppointment={handleBookAppointment}
        />
      )}
    </div>
  );
}
